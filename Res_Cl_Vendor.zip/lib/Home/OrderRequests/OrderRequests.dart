import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter_svg/svg.dart';

class OrderReq extends StatefulWidget {
  const OrderReq({Key? key}) : super(key: key);

  @override
  State<OrderReq> createState() => _OrderReqState();
}

class _OrderReqState extends State<OrderReq> {
  final List<Map<String, dynamic>> dataList = [
    {
      'name': 'Item 1',
      'description': 'Description for Item 1',
      'price': 10.99,
    },
    {
      'name': 'Item 2',
      'description': 'Description for Item 2',
      'price': 20.49,
    },
    {
      'name': 'Item 3',
      'description': 'Description for Item 3',
      'price': 5.99,
    },
    // Add more items as needed
  ];
  @override
  Widget build(BuildContext context) {
    var mQuery = MediaQuery.of(context);
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          color: Color(0xff006acb),
        ),
        child: Column(
          children: [
            SizedBox(height: mQuery.size.height * 0.034),
            Padding(
              padding: const EdgeInsets.only(
                  top: 45, left: 16, right: 16, bottom: 20),
              child: Row(
                children: [
                  const Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                  ),
                  SizedBox(
                    width: mQuery.size.width * 0.045,
                  ),
                  Text(
                    AppLocalizations.of(context)!.orderrequest,
                    style: const TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                        fontWeight: FontWeight.w700),
                  )
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 0.3,
                      blurRadius: 1,
                      offset: const Offset(
                          3, 3), // changes the position of the shadow
                    ),
                  ],
                ),
                child: Padding(
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    child: ListView.builder(
                      itemCount: dataList
                          .length, // Replace dataList with your list of dynamic data
                      itemBuilder: (context, index) {
                        final Map<String, dynamic> data = dataList[index];
                        return Container(
                          width: mQuery.size.width * 0.9,
                          height: mQuery.size.height * 0.35,
                          color: Colors.white,
                          padding: EdgeInsets.all(mQuery.size.width * 0.02),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                color: Color(0xffe9f8ff),
                                width: double.infinity,
                                height: mQuery.size.height * 0.06,
                                padding: EdgeInsets.symmetric(
                                    horizontal: mQuery.size.width * 0.02),
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      backgroundImage: NetworkImage(
                                          "https://images.news18.com/ibnkhabar/uploads/2023/09/IFS-Apala-mishra-age-upsc-rank-education-biography-in-hindi-marksheet-salary-1.jpg"),
                                    ),
                                    SizedBox(
                                      width: mQuery.size.width * 0.02,
                                    ),
                                    Text(
                                      data['name'],
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    Expanded(child: SizedBox()),
                                    Icon(
                                      Icons.star,
                                      size: mQuery.size.width * 0.047,
                                      color: Color(0xff29b2fe),
                                    ),
                                    SizedBox(
                                      width: mQuery.size.width * 0.01,
                                    ),
                                    Text(
                                      "1.0",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w600),
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: mQuery.size.height * 0.01,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Location",
                                    style: TextStyle(
                                        color: Colors.black54, fontSize: 13),
                                  ),
                                  Text(
                                    "Accept in",
                                    style: TextStyle(
                                        color: Colors.black54, fontSize: 13),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: mQuery.size.width * 0.06,
                                    height: mQuery.size.height * 0.035,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(0xff29b2fe)),
                                    child: Center(
                                      child: Icon(
                                        Icons.home,
                                        color: Colors.white,
                                        size: mQuery.size.width * 0.04,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: mQuery.size.width * 0.02,
                                  ),
                                  Text(
                                    "PDPU Crossroad, kudasan (1.2km)",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  Expanded(child: SizedBox()),
                                  Text(
                                    "00h:30m",
                                    style: TextStyle(
                                        color: Color(0xff29b2fe),
                                        fontWeight: FontWeight.w600),
                                  )
                                ],
                              ),
                              Divider(),
                              SizedBox(
                                height: mQuery.size.height * 0.02,
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: mQuery.size.width * 0.38,
                                    height: mQuery.size.height * 0.1,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Pickup Date & Time",
                                          style: TextStyle(
                                              color: Colors.black54,
                                              fontSize: 12),
                                        ),
                                        SizedBox(
                                          height: mQuery.size.height * 0.006,
                                        ),
                                        Text(
                                          "25 June | 04pm - 06pm",
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600),
                                        )
                                      ],
                                    ),
                                  ),
                                  VerticalDivider(
                                    color: Colors.black54,
                                    width: 2,
                                  ),
                                  VerticalDivider(),
                                  Expanded(child: SizedBox()),
                                  Container(
                                    width: mQuery.size.width * 0.38,
                                    height: mQuery.size.height * 0.1,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Delivery Date & Time",
                                          style: TextStyle(
                                              color: Colors.black54,
                                              fontSize: 12),
                                        ),
                                        SizedBox(
                                          height: mQuery.size.height * 0.006,
                                        ),
                                        Text(
                                          "25 June | 04pm - 06pm",
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600),
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: mQuery.size.width * 0.43,
                                    height: mQuery.size.height * 0.045,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.only(
                                            bottomLeft: Radius.circular(6)),
                                        color: Color(0xff004c90)),
                                    child: Center(
                                      child: Text(
                                        "REJECT ORDER",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: mQuery.size.width * 0.43,
                                    height: mQuery.size.height * 0.045,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.only(
                                            bottomRight: Radius.circular(6)),
                                        color: Color(0xff29b2fe)),
                                    child: Center(
                                      child: Text(
                                        "ACCEPT ORDER",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    )),
              ),
            )
          ],
        ),
      ),
    );
  }
}
